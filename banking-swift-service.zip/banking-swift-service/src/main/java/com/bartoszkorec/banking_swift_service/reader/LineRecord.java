package com.bartoszkorec.banking_swift_service.reader;

public record LineRecord(String[] fields, int lineNumber) {
}
