package com.bartoszkorec.banking_swift_service.exception;

public class InvalidHeadquartersException extends RuntimeException {
    public InvalidHeadquartersException(String message) {
        super(message);
    }
}
