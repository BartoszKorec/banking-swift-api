package com.bartoszkorec.banking_swift_service.exception;

public class FileException extends RuntimeException {
    public FileException(String message) {
        super(message);
    }
}
